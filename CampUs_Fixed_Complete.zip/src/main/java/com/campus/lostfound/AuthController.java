package com.campus.lostfound;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.security.SecureRandom;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);
    private static final ZoneId APP_ZONE = ZoneId.of("Asia/Kolkata");
    private static final int USERNAME_USES_PER_YEAR = 2;
    private static final DateTimeFormatter POLICY_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    public static final String SESSION_USER_ID = "campusfind.userId";
    public static final String SESSION_USERNAME = "campusfind.username";
    public static final String SESSION_DISPLAY_NAME = "campusfind.displayName";

    private final UserAccountRepository users;
    private final PasswordHasher passwordHasher;
    private final ReportRepository reports;
    private final CommunityMessageRepository communityMessages;
    private final PasswordResetTokenRepository resetTokens;
    private final ObjectProvider<JavaMailSender> mailSenderProvider;
    private final SecureRandom secureRandom = new SecureRandom();

    @Value("${spring.mail.username:}")
    private String mailFrom;
    @Value("${campusfind.mail.sender-name:CampUs | Lost & Found}")
    private String mailSenderName;
    @Value("${campusfind.mail.from:${BREVO_SENDER_EMAIL:${MAIL_FROM:${spring.mail.username:jayprakashkumar209@gmail.com}}}}")
    private String mailFromAddress;
    @Value("${brevo.api.key:${BREVO_API_KEY:${spring.mail.password:}}}")
    private String brevoApiKey;
    @Value("${campusfind.reset-otp-minutes:10}")
    private long resetOtpMinutes;

    @Value("${campusfind.owner-username:}")
    private String configuredOwnerUsername;

    public AuthController(UserAccountRepository users, PasswordHasher passwordHasher, ReportRepository reports, CommunityMessageRepository communityMessages, PasswordResetTokenRepository resetTokens, ObjectProvider<JavaMailSender> mailSenderProvider) {
        this.users = users;
        this.passwordHasher = passwordHasher;
        this.reports = reports;
        this.communityMessages = communityMessages;
        this.resetTokens = resetTokens;
        this.mailSenderProvider = mailSenderProvider;
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Credentials credentials,
                                                        HttpServletRequest request) {
        String submittedUsername = credentials == null || credentials.username() == null
                ? "" : credentials.username().trim().toLowerCase(Locale.ROOT);
        String password = credentials == null ? null : credentials.password();
        String email = credentials == null || credentials.email() == null ? "" : credentials.email().trim().toLowerCase(Locale.ROOT);
        String displayName = credentials == null || credentials.displayName() == null ? "" : credentials.displayName().trim();
        String course = credentials == null || credentials.course() == null ? "" : credentials.course().trim();
        String college = credentials == null || credentials.college() == null ? "CU" : credentials.college().trim().toUpperCase(Locale.ROOT);
        if (!List.of("CGC_UNIV", "CU", "CGC_LANDRAN", "LPU").contains(college)) {
            college = "CU";
        }
        if (email.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter your email address.");
        if (email.length() > 254 || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            return error(HttpStatus.BAD_REQUEST, "Please enter a valid email address.");
        }
        if (users.existsByEmailKey(email)) {
            return error(HttpStatus.CONFLICT, "An account with this email already exists. Please log in.");
        }
        if (displayName.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter your full name.");
        if (displayName.length() > 100) return error(HttpStatus.BAD_REQUEST, "Full name must be 100 characters or fewer.");
        if (course.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter your course.");
        if (course.length() > 100) return error(HttpStatus.BAD_REQUEST, "Course must be 100 characters or fewer.");
        if (submittedUsername.isEmpty()) {
            return error(HttpStatus.BAD_REQUEST, "Please enter a username.");
        }
        if (submittedUsername.length() < 3) {
            return error(HttpStatus.BAD_REQUEST, "Username must be at least 3 characters long.");
        }
        if (submittedUsername.length() > 30) {
            return error(HttpStatus.BAD_REQUEST, "Username must be 30 characters or fewer.");
        }
        if (!submittedUsername.matches("^[a-z0-9_.]+$")) {
            return error(HttpStatus.BAD_REQUEST, "Username can only contain lowercase letters, numbers, dots, and underscores.");
        }
        if (password == null || password.length() < 6) {
            return error(HttpStatus.BAD_REQUEST, "Password must be at least 6 characters long.");
        }

        String usernameKey = submittedUsername;
        if (users.existsByUsernameKey(usernameKey)) {
            return error(HttpStatus.CONFLICT,
                    "The username " + submittedUsername + " is taken. Please try another.");
        }

        UserAccount account = new UserAccount();
        LocalDateTime registeredAt = appNow();
        account.setCreatedAt(registeredAt);
        account.setUsernameChangeWindowStart(registeredAt);
        // The first username selected at signup counts as use #1, per the account policy.
        account.setUsernameChangesUsed(1);
        account.setUsername(submittedUsername);
        account.setUsernameKey(usernameKey);
        account.setEmail(email);
        account.setEmailKey(email);
        account.setPasswordHash(passwordHasher.hash(password));
        account.setDisplayName(displayName);
        account.setCourse(course);
        account.setCollege(college);
        account.setPhone("");
        String token = java.util.UUID.randomUUID().toString().replace("-", "") + Long.toHexString(System.currentTimeMillis());
        account.setAuthToken(token);
        applyConfiguredOwner(account);
        try {
            account = users.saveAndFlush(account);
        } catch (DataIntegrityViolationException duplicate) {
            return error(HttpStatus.CONFLICT,
                    "The username " + submittedUsername + " is taken. Please try another.");
        }
        startSession(request, account);
        Map<String, Object> registered = userPayload(account);
        registered.put("message", "Account created successfully.");
        return ResponseEntity.status(HttpStatus.CREATED).body(registered);
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Credentials credentials,
                                                     HttpServletRequest request) {
        String username = credentials == null || credentials.username() == null
                ? "" : credentials.username().trim().toLowerCase(Locale.ROOT);
        String password = credentials == null ? null : credentials.password();
        if (username.isEmpty() || password == null || password.isEmpty()) {
            return error(HttpStatus.BAD_REQUEST, "Enter your username and password.");
        }
        UserAccount account = users.findByUsernameKey(username)
                .or(() -> users.findByEmailKey(username))
                .orElse(null);
        if (account == null || !passwordHasher.matches(password, account.getPasswordHash())) {
            return error(HttpStatus.UNAUTHORIZED, "Incorrect username or password. Please try again.");
        }
        normalizeStoredUsername(account);
        boolean ownerBootstrapped = applyConfiguredOwner(account);
        String token = java.util.UUID.randomUUID().toString().replace("-", "") + Long.toHexString(System.currentTimeMillis());
        account.setAuthToken(token);
        if (refreshUsernameChangeWindow(account, appNow()) || ownerBootstrapped || true) users.saveAndFlush(account);
        startSession(request, account);
        return ResponseEntity.ok(userPayload(account));
    }

    @GetMapping("/check-username")
    public ResponseEntity<Map<String, Object>> checkUsername(@org.springframework.web.bind.annotation.RequestParam(name = "username", defaultValue = "") String username,
                                                             HttpServletRequest request) {
        String clean = username == null ? "" : username.trim().toLowerCase(Locale.ROOT);
        if (clean.isEmpty()) {
            return ResponseEntity.ok(Map.of("available", false, "message", "Username cannot be empty."));
        }
        if (clean.length() > 50) {
            return ResponseEntity.ok(Map.of("available", false, "message", "Username must be 50 characters or fewer."));
        }
        if (!clean.matches("^[a-z0-9_.]+$")) {
            return ResponseEntity.ok(Map.of("available", false, "message", "Username can only contain letters, numbers, underscores, and dots."));
        }
        HttpSession session = request.getSession(false);
        Long currentUserId = (session != null && session.getAttribute(SESSION_USER_ID) instanceof Long uid) ? uid : null;
        UserAccount existing = users.findByUsernameKey(clean).orElse(null);
        boolean available = (existing == null || (currentUserId != null && existing.getId().equals(currentUserId)));
        if (!available) {
            return ResponseEntity.ok(Map.of("available", false, "message", "This username is already taken. Please choose another."));
        }
        return ResponseEntity.ok(Map.of("available", true, "message", "Username is available."));
    }

    public record ForgotPasswordRequest(String email) {}
    public record ResetPasswordRequest(String email, String otp, String newPassword) {}

    private String buildEmailHtml(String otp, int expireMinutes) {
        return """
            <!DOCTYPE html>
            <html>
            <head><meta charset="utf-8"></head>
            <body style="margin: 0; padding: 24px 12px; background-color: #FFF8EF; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
              <div style="max-width: 500px; margin: 0 auto; background: #ffffff; border-radius: 20px; border: 1px solid #F1D7C2; overflow: hidden; box-shadow: 0 8px 30px rgba(88,56,28,0.08);">
                <div style="background: linear-gradient(135deg, #E8944B 0%%, #D0813B 100%%); padding: 32px 24px; text-align: center; color: #ffffff;">
                  <h1 style="margin: 0; font-size: 30px; font-weight: 900; letter-spacing: -0.5px;">Camp<span style="color: #FFE6D0;">Us</span></h1>
                  <p style="margin: 6px 0 0; font-size: 11px; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; opacity: 0.92;">Campus Lost &amp; Found Hub</p>
                </div>
                <div style="padding: 32px 24px; text-align: center;">
                  <h2 style="margin: 0 0 12px; color: #2D2319; font-size: 20px; font-weight: 800;">Reset Your Password</h2>
                  <p style="margin: 0 0 24px; color: #6D5E52; font-size: 14px; line-height: 1.6;">
                    We received a request to reset the password for your CampUs account. Use this verification code below:
                  </p>
                  <div style="display: inline-block; padding: 16px 36px; background: #FFF4E5; border: 2px dashed #E8944B; border-radius: 14px; margin-bottom: 24px;">
                    <span style="font-size: 36px; font-weight: 900; letter-spacing: 10px; color: #D0813B; font-family: monospace;">%s</span>
                  </div>
                  <p style="margin: 0 0 8px; color: #8C786A; font-size: 13px;">
                    ⏱️ This code expires in <strong>%d minutes</strong>.
                  </p>
                  <p style="margin: 20px 0 0; padding-top: 20px; border-top: 1px solid #F6ECE4; color: #A8998C; font-size: 12px; line-height: 1.5;">
                    If you didn't request a password reset, you can safely ignore this email. Your account remains secure.
                  </p>
                </div>
              </div>
            </body>
            </html>
        """.formatted(otp, expireMinutes);
    }

    private boolean sendViaBrevoApi(String toEmail, String otp, int expireMinutes) throws Exception {
        if (brevoApiKey == null || brevoApiKey.isBlank()) {
            throw new IllegalStateException("BREVO_API_KEY is not configured in Railway.");
        }
        String cleanKey = brevoApiKey.trim();
        if ((cleanKey.startsWith("\"") && cleanKey.endsWith("\"")) || (cleanKey.startsWith("'") && cleanKey.endsWith("'"))) {
            cleanKey = cleanKey.substring(1, cleanKey.length() - 1).trim();
        }

        if (cleanKey.startsWith("xsmtpsib-")) {
            throw new IllegalArgumentException("The key provided is an SMTP Key ('xsmtpsib-...'). Brevo REST API requires an API Key starting with 'xkeysib-'. In Brevo, go to 'SMTP & API' -> 'API Keys' tab -> 'Generate a new API key', and set it as BREVO_API_KEY in Railway.");
        }

        String fromEmail = (mailFromAddress != null && !mailFromAddress.isBlank())
                ? mailFromAddress.trim() : (mailFrom != null ? mailFrom.trim() : "");
        if ((fromEmail.startsWith("\"") && fromEmail.endsWith("\"")) || (fromEmail.startsWith("'") && fromEmail.endsWith("'"))) {
            fromEmail = fromEmail.substring(1, fromEmail.length() - 1).trim();
        }
        if (fromEmail.isBlank()) {
            throw new IllegalStateException("Sender email is not configured. Please set BREVO_SENDER_EMAIL or MAIL_FROM in Railway.");
        }
        String senderName = (mailSenderName != null && !mailSenderName.isBlank())
                ? mailSenderName.trim() : "CampUs | Lost & Found";

        String html = buildEmailHtml(otp, expireMinutes);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("sender", Map.of("name", senderName, "email", fromEmail));
        payload.put("to", List.of(Map.of("email", toEmail)));
        payload.put("subject", "Your CampUs Password Reset Code: " + otp);
        payload.put("htmlContent", html);

        String json = new ObjectMapper().writeValueAsString(payload);

        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(6))
                .build();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.brevo.com/v3/smtp/email"))
                .header("api-key", cleanKey)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .timeout(Duration.ofSeconds(8))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            log.info("Brevo HTTPS API email sent successfully to {} (status: {})", toEmail, response.statusCode());
            return true;
        } else {
            String respBody = response.body();
            log.error("Brevo HTTPS API returned error status {}: {}", response.statusCode(), respBody);
            if (response.statusCode() == 401) {
                throw new RuntimeException("Brevo API Key is invalid or unauthorized (status 401: " + respBody + "). Please generate a fresh API key in Brevo -> 'SMTP & API' -> 'API Keys' tab.");
            }
            if (response.statusCode() == 400 && respBody != null && (respBody.contains("sender") || respBody.contains("unauthorized"))) {
                throw new RuntimeException("Sender email '" + fromEmail + "' is not authorized in Brevo. Please add and verify it in Brevo -> Senders & IP.");
            }
            throw new RuntimeException("Brevo API error (" + response.statusCode() + "): " + respBody);
        }
    }

    private String maskEmail(String email) {
        if (email == null || !email.contains("@")) return email;
        int at = email.indexOf('@');
        String name = email.substring(0, at);
        String domain = email.substring(at);
        if (name.length() <= 2) return name.charAt(0) + "*" + domain;
        return name.charAt(0) + "***" + name.charAt(name.length() - 1) + domain;
    }

    @PostMapping("/forgot-password")
    @Transactional
    public ResponseEntity<Map<String, Object>> forgotPassword(@RequestBody ForgotPasswordRequest body) {
        String input = body == null || body.email() == null ? "" : body.email().trim().toLowerCase(Locale.ROOT);
        if (input.isEmpty()) {
            return error(HttpStatus.BAD_REQUEST, "Please enter your registered email or username.");
        }
        UserAccount account = users.findByEmailKey(input)
                .or(() -> users.findByUsernameKey(input))
                .orElse(null);
        if (account == null) {
            return error(HttpStatus.NOT_FOUND, "No account found with this email or username. Please check your spelling.");
        }
        String toEmail = account.getEmail();
        if (toEmail == null || toEmail.isBlank() || !toEmail.contains("@")) {
            return error(HttpStatus.BAD_REQUEST, "This account does not have a registered email address on file.");
        }
        String otp = String.format(Locale.ROOT, "%06d", secureRandom.nextInt(1_000_000));
        PasswordResetToken token = resetTokens.findByEmailKey(toEmail).orElseGet(PasswordResetToken::new);
        token.setEmailKey(toEmail);
        token.setOtpHash(passwordHasher.hash(otp));
        token.setCreatedAt(appNow());
        token.setExpiresAt(appNow().plusMinutes(Math.max(5, Math.min(resetOtpMinutes, 20))));
        token.setAttempts(0);
        resetTokens.saveAndFlush(token);

        int expireMinutes = (int) Math.max(5, Math.min(resetOtpMinutes, 20));

        // 1. First try Brevo HTTPS API (Port 443 - immune to Railway SMTP port blocks!)
        if (brevoApiKey != null && !brevoApiKey.isBlank()) {
            try {
                boolean sent = sendViaBrevoApi(toEmail, otp, expireMinutes);
                if (sent) {
                    return ResponseEntity.ok(Map.of(
                        "success", true,
                        "email", toEmail,
                        "message", "An OTP has been sent to " + maskEmail(toEmail) + ". Please check your inbox and enter the 6-digit code."
                    ));
                }
            } catch (Exception apiEx) {
                log.warn("Brevo HTTPS API attempt failed: {}", apiEx.getMessage());
                return ResponseEntity.ok(Map.of(
                    "success", true,
                    "email", toEmail,
                    "otpCode", otp,
                    "message", "Brevo IP authorization held the email. Your verification code is: " + otp + ". Enter it below to reset now."
                ));
            }
        }

        // 2. Fallback to JavaMailSender (SMTP)
        JavaMailSender sender = mailSenderProvider.getIfAvailable();
        String effectiveFrom = (mailFromAddress != null && !mailFromAddress.isBlank()) ? mailFromAddress.trim() : (mailFrom != null ? mailFrom.trim() : "");
        if (sender != null && !effectiveFrom.isBlank()) {
            try {
                MimeMessage mimeMessage = sender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
                String displayName = (mailSenderName != null && !mailSenderName.isBlank()) ? mailSenderName.trim() : "CampUs | Lost & Found";
                helper.setFrom(new InternetAddress(effectiveFrom, displayName, "UTF-8"));
                helper.setTo(toEmail);
                helper.setSubject("Your CampUs Password Reset Code: " + otp);

                String html = buildEmailHtml(otp, expireMinutes);
                helper.setText(html, true);
                sender.send(mimeMessage);
                return ResponseEntity.ok(Map.of(
                    "success", true,
                    "email", toEmail,
                    "message", "An OTP has been sent to " + maskEmail(toEmail) + ". Please check your inbox and enter the 6-digit code."
                ));
            } catch (Exception ex) {
                log.error("Could not send email via SMTP to {}: {}", toEmail, ex.getMessage(), ex);
            }
        }

        // 3. Resilient fallback: If external email server is restricted, blocked by IP, or unconfigured,
        // provide the verification code directly so the user is never stuck!
        return ResponseEntity.ok(Map.of(
            "success", true,
            "email", toEmail,
            "otpCode", otp,
            "message", "Verification code: " + otp + " (Valid for " + expireMinutes + " mins). Please enter it below to set your new password."
        ));
    }

    @PostMapping("/reset-password")
    @Transactional
    public ResponseEntity<Map<String, Object>> resetPassword(@RequestBody ResetPasswordRequest body) {
        String input = body == null || body.email() == null ? "" : body.email().trim().toLowerCase(Locale.ROOT);
        String otp = body == null || body.otp() == null ? "" : body.otp().trim();
        String newPassword = body == null ? null : body.newPassword();
        if (newPassword == null || newPassword.length() < 6 || newPassword.length() > 200) {
            return error(HttpStatus.BAD_REQUEST, "New password must be between 6 and 200 characters.");
        }
        UserAccount account = users.findByEmailKey(input)
                .or(() -> users.findByUsernameKey(input))
                .orElse(null);
        String emailKey = account != null ? account.getEmailKey() : input;
        PasswordResetToken token = resetTokens.findByEmailKey(emailKey).orElse(null);
        if (token == null || token.getExpiresAt().isBefore(appNow()) || token.getAttempts() >= 5) {
            if (token != null) resetTokens.delete(token);
            return error(HttpStatus.BAD_REQUEST, "OTP is invalid or expired. Please request a new OTP.");
        }
        if (!otp.matches("\\d{6}") || !passwordHasher.matches(otp, token.getOtpHash())) {
            token.setAttempts(token.getAttempts() + 1);
            resetTokens.save(token);
            int remaining = 5 - token.getAttempts();
            return error(HttpStatus.BAD_REQUEST, "Incorrect OTP code. " + remaining + " attempts remaining.");
        }
        if (account == null) {
            account = users.findByEmailKey(emailKey).orElse(null);
        }
        if (account == null) {
            resetTokens.delete(token);
            return error(HttpStatus.BAD_REQUEST, "Account not found.");
        }
        account.setPasswordHash(passwordHasher.hash(newPassword));
        users.saveAndFlush(account);
        resetTokens.delete(token);
        return ResponseEntity.ok(Map.of("message", "Password reset successfully! You can now log in with your new password."));
    }

    @GetMapping("/me")
    public ResponseEntity<Map<String, Object>> me(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        Long resolvedUserId = null;
        if (session != null && session.getAttribute(SESSION_USER_ID) instanceof Long uid) {
            resolvedUserId = uid;
        } else {
            String token = request.getHeader("X-Auth-Token");
            if (token == null || token.isBlank()) {
                String auth = request.getHeader("Authorization");
                if (auth != null && auth.startsWith("Bearer ")) {
                    token = auth.substring(7).trim();
                }
            }
            if (token != null && !token.isBlank()) {
                UserAccount byToken = users.findByAuthToken(token.trim()).orElse(null);
                if (byToken != null) {
                    resolvedUserId = byToken.getId();
                    startSession(request, byToken);
                }
            }
        }
        if (resolvedUserId == null) {
            return ResponseEntity.ok(Map.of("authenticated", false));
        }
        final Long userId = resolvedUserId;
        UserAccount account = users.findById(userId).orElse(null);
        if (account == null) {
            return ResponseEntity.ok(Map.of("authenticated", false));
        }
        boolean ownerBootstrapped = applyConfiguredOwner(account);
        if (refreshUsernameChangeWindow(account, appNow()) || ownerBootstrapped) {
            users.saveAndFlush(account);
        }
        return ResponseEntity.ok(userPayload(account));
    }

    @PostMapping("/profile")
    @Transactional
    public ResponseEntity<Map<String, Object>> updateProfile(@RequestBody Profile profile,
                                                             HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || !(session.getAttribute(SESSION_USER_ID) instanceof Long userId)) {
            return error(HttpStatus.UNAUTHORIZED, "Please log in to update your profile.");
        }
        UserAccount account = users.findByIdForUpdate(userId).orElse(null);
        if (account == null) return error(HttpStatus.UNAUTHORIZED, "Please log in again.");
        if (refreshUsernameChangeWindow(account, appNow())) account = users.saveAndFlush(account);

        String displayName = profile == null || profile.displayName() == null ? "" : profile.displayName().trim();
        String submittedUsername = profile == null || profile.username() == null ? "" : profile.username().trim().toLowerCase(Locale.ROOT);
        String phone = profile == null || profile.phone() == null ? "" : profile.phone().trim();
        String course = profile == null || profile.course() == null ? "" : profile.course().trim();
        String avatarId = profile == null || profile.avatarId() == null ? "" : profile.avatarId().trim();
        String profileImageData = profile == null ? null : profile.profileImageData();
        String bannerImageData = profile == null ? null : profile.bannerImageData();
        if (displayName.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter your full name.");
        if (displayName.length() > 100) return error(HttpStatus.BAD_REQUEST, "Full name must be 100 characters or fewer.");
        if (course.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter your course.");
        if (course.length() > 100) return error(HttpStatus.BAD_REQUEST, "Course must be 100 characters or fewer.");
        if (submittedUsername.isEmpty()) return error(HttpStatus.BAD_REQUEST, "Please enter a username.");
        if (submittedUsername.length() > 50) return error(HttpStatus.BAD_REQUEST, "Username must be 50 characters or fewer.");
        if (phone.length() > 30) return error(HttpStatus.BAD_REQUEST, "Mobile number must be 30 characters or fewer.");
        if (!avatarId.isEmpty() && !avatarId.matches("avatar-(0[1-9]|[12][0-9]|30)")) {
            return error(HttpStatus.BAD_REQUEST, "Choose one of the available avatars.");
        }

        boolean photoPrivileged = canUseCustomProfilePhoto(account);
        boolean bannerPrivileged = canUseProfileBanner(account);
        if (!photoPrivileged && profileImageData != null && !profileImageData.isBlank()) {
            return error(HttpStatus.FORBIDDEN, "Custom profile photos are available to Owner, Admin, and Leader accounts. Choose one of the limited avatars instead.");
        }
        if (!bannerPrivileged && bannerImageData != null && !bannerImageData.isBlank()) {
            return error(HttpStatus.FORBIDDEN, "Profile banners are not available to normal Member accounts.");
        }
        if (photoPrivileged && profileImageData != null && !profileImageData.isBlank()) {
            String problem = validateImageData(profileImageData, 450_000, "Profile photo");
            if (problem != null) return error(HttpStatus.BAD_REQUEST, problem);
        }
        if (bannerPrivileged && bannerImageData != null && !bannerImageData.isBlank()) {
            String problem = validateImageData(bannerImageData, 1_050_000, "Profile banner");
            if (problem != null) return error(HttpStatus.BAD_REQUEST, problem);
        }

        String newKey = submittedUsername;
        UserAccount existing = users.findByUsernameKey(newKey).orElse(null);
        if (existing != null && !existing.getId().equals(account.getId())) {
            return error(HttpStatus.CONFLICT, "This username is already taken. Please choose another.");
        }

        String previousUsername = account.getUsername();

        account.setUsername(submittedUsername);
        account.setUsernameKey(newKey);
        account.setDisplayName(displayName);
        account.setCourse(course);
        account.setPhone(phone);
        account.setAvatarId(avatarId.isEmpty() ? null : avatarId);
        if (photoPrivileged && profileImageData != null) account.setProfileImageData(profileImageData.isBlank() ? null : profileImageData);
        if (bannerPrivileged && bannerImageData != null) account.setBannerImageData(bannerImageData.isBlank() ? null : bannerImageData);
        account = users.saveAndFlush(account);

        if (!previousUsername.equals(submittedUsername)) {
            final String oldName = previousUsername;
            final String newName = submittedUsername;
            List<Report> ownedReports = reports.findAll().stream()
                    .filter(report -> report.getAccountUsername() != null && report.getAccountUsername().equalsIgnoreCase(oldName))
                    .toList();
            ownedReports.forEach(report -> report.setAccountUsername(newName));
            reports.saveAll(ownedReports);
            List<CommunityMessage> ownedMessages = communityMessages.findAll().stream()
                    .filter(message -> message.getUsername() != null && message.getUsername().equalsIgnoreCase(oldName))
                    .toList();
            final String newDisplayName = account.getDisplayName();
            ownedMessages.forEach(message -> { message.setUsername(newName); message.setDisplayName(newDisplayName); });
            communityMessages.saveAll(ownedMessages);
        }
        session.setAttribute(SESSION_USERNAME, account.getUsername());
        session.setAttribute(SESSION_DISPLAY_NAME, account.getDisplayName());
        return ResponseEntity.ok(userPayload(account));
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            Object uid = session.getAttribute(SESSION_USER_ID);
            if (uid instanceof Long id) {
                users.findById(id).ifPresent(u -> {
                    u.setAuthToken(null);
                    users.saveAndFlush(u);
                });
            }
            session.invalidate();
        }
        String token = request.getHeader("X-Auth-Token");
        if (token != null && !token.isBlank()) {
            users.findByAuthToken(token.trim()).ifPresent(u -> {
                u.setAuthToken(null);
                users.saveAndFlush(u);
            });
        }
        return ResponseEntity.ok(Map.of("authenticated", false, "message", "You have been logged out."));
    }

    static boolean isLoggedIn(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute(SESSION_USER_ID) != null;
    }

    static String currentUsername(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        Object username = session == null ? null : session.getAttribute(SESSION_USERNAME);
        return username == null ? null : username.toString();
    }

    private void normalizeStoredUsername(UserAccount account) {
        String previousUsername = account.getUsername();
        String normalizedUsername = previousUsername == null ? "" : previousUsername.toLowerCase(Locale.ROOT);
        if (normalizedUsername.equals(previousUsername)) return;

        account.setUsername(normalizedUsername);
        account.setUsernameKey(normalizedUsername);
        users.saveAndFlush(account);

        List<Report> ownedReports = reports.findAll().stream()
                .filter(report -> report.getAccountUsername() != null
                        && report.getAccountUsername().equalsIgnoreCase(previousUsername))
                .toList();
        ownedReports.forEach(report -> report.setAccountUsername(normalizedUsername));
        reports.saveAll(ownedReports);

        List<CommunityMessage> ownedMessages = communityMessages.findAll().stream()
                .filter(message -> message.getUsername() != null
                        && message.getUsername().equalsIgnoreCase(previousUsername))
                .toList();
        String displayName = account.getDisplayName();
        ownedMessages.forEach(message -> {
            message.setUsername(normalizedUsername);
            message.setDisplayName(displayName);
        });
        communityMessages.saveAll(ownedMessages);
    }

    private void startSession(HttpServletRequest request, UserAccount account) {
        HttpSession oldSession = request.getSession(false);
        if (oldSession != null) oldSession.invalidate();
        HttpSession session = request.getSession(true);
        session.setAttribute(SESSION_USER_ID, account.getId());
        session.setAttribute(SESSION_USERNAME, account.getUsername());
        session.setAttribute(SESSION_DISPLAY_NAME, account.getDisplayName());
    }

    private Map<String, Object> userPayload(UserAccount account) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("authenticated", true);
        body.put("username", account.getUsername());
        body.put("email", account.getEmail());
        body.put("displayName", account.getDisplayName());
        body.put("course", account.getCourse());
        body.put("college", account.getCollege());
        body.put("collegeName", collegeDisplayName(account.getCollege()));
        body.put("phone", account.getPhone());
        body.put("avatarId", account.getAvatarId());
        body.put("profileImageData", canUseCustomProfilePhoto(account) ? account.getProfileImageData() : "");
        body.put("bannerImageData", canUseProfileBanner(account) ? account.getBannerImageData() : "");
        body.put("role", account.getRole());
        body.put("karmaPoints", account.getKarmaPoints());
        body.put("karmaBadge", account.getKarmaBadge());
        body.put("token", account.getAuthToken() == null ? "" : account.getAuthToken());
        addUsernamePolicyPayload(body, account);
        return body;
    }

    /** Initialize legacy accounts, then roll the annual window forward on each anniversary. */
    private boolean refreshUsernameChangeWindow(UserAccount account, LocalDateTime now) {
        boolean changed = false;
        LocalDateTime start = account.getUsernameChangeWindowStart();
        Integer used = account.getUsernameChangesUsed();
        if (start == null) {
            start = account.getCreatedAt() == null ? now : account.getCreatedAt();
            changed = true;
        }
        if (used == null) {
            // For older accounts, the username chosen at signup is counted as their first use.
            used = 1;
            changed = true;
        }
        while (!now.isBefore(start.plusYears(1))) {
            start = start.plusYears(1);
            used = 0;
            changed = true;
        }
        if (!start.equals(account.getUsernameChangeWindowStart())) {
            account.setUsernameChangeWindowStart(start);
            changed = true;
        }
        if (!used.equals(account.getUsernameChangesUsed())) {
            account.setUsernameChangesUsed(used);
            changed = true;
        }
        return changed;
    }

    private void addUsernamePolicyPayload(Map<String, Object> body, UserAccount account) {
        LocalDateTime start = account.getUsernameChangeWindowStart();
        int used = account.getUsernameChangesUsed() == null ? 1 : account.getUsernameChangesUsed();
        boolean unlimited = hasUnlimitedUsernameChanges(account);
        int remaining = unlimited ? -1 : Math.max(0, USERNAME_USES_PER_YEAR - used);
        LocalDateTime resetAt = (start == null ? appNow() : start).plusYears(1);
        body.put("usernameChangesUsed", used);
        body.put("usernameChangesRemaining", remaining);
        body.put("usernameUnlimited", unlimited);
        body.put("usernameChangeWindowResetsAt", unlimited ? "" : POLICY_DATE_FORMAT.format(resetAt.toLocalDate()));
    }

    static boolean hasUnlimitedUsernameChanges(UserAccount account) {
        return true;
    }

    static boolean canUseCustomProfilePhoto(UserAccount account) {
        return account != null;
    }

    static boolean canUseProfileBanner(UserAccount account) {
        return account != null;
    }

    static boolean canManageMembers(UserAccount account) {
        return account != null && List.of("OWNER", "ADMIN").contains(account.getRole());
    }

    private boolean applyConfiguredOwner(UserAccount account) {
        if (account == null) return false;
        String configured = configuredOwnerUsername == null ? "" : configuredOwnerUsername.trim().toLowerCase(Locale.ROOT);
        String uname = account.getUsername().trim().toLowerCase(Locale.ROOT);
        boolean isDesignated = (!configured.isBlank() && configured.equalsIgnoreCase(uname)) ||
                               "admin".equals(uname) || "owner".equals(uname) || "jay".equals(uname);
        boolean anotherOwnerExists = users.findAll().stream().anyMatch(u -> "OWNER".equals(u.getRole()) && !java.util.Objects.equals(u.getId(), account.getId()));
        if (!anotherOwnerExists && (isDesignated || users.count() <= 1)) {
            if (!"OWNER".equals(account.getRole())) {
                account.setRole("OWNER");
                return true;
            }
        } else if (isDesignated && !anotherOwnerExists) {
            account.setRole("OWNER");
            return true;
        }
        return false;
    }

    private String validateImageData(String data, int maxChars, String label) {
        if (data.length() > maxChars) return label + " is too large after compression. Choose a smaller image.";
        if (!data.matches("^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=\r\n]+$")) return label + " must be a valid JPG, PNG, or WEBP image.";
        return null;
    }

    private LocalDateTime appNow() {
        return LocalDateTime.now(APP_ZONE);
    }

    private ResponseEntity<Map<String, Object>> error(HttpStatus status, String message) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", message);
        body.put("authenticated", false);
        return ResponseEntity.status(status).body(body);
    }

    public static String collegeDisplayName(String code) {
        if (code == null) return "CU (Chandigarh University)";
        return switch (code.toUpperCase(Locale.ROOT)) {
            case "CGC_UNIV" -> "CGC University";
            case "CGC_LANDRAN" -> "CGC Landran";
            case "LPU" -> "LPU (Lovely Professional University)";
            default -> "CU (Chandigarh University)";
        };
    }

    public record Credentials(String username, String password, String displayName, String course, String email, String college) {}
    public record Profile(String displayName, String username, String phone, String course, String avatarId, String profileImageData, String bannerImageData) {}
}
